// function f1() {
//     alert("Hello");
// }
// let req = require("request");
// let cher = require("cheerio");
// const { html } = require("cheerio");
// let url = "https://timesofindia.indiatimes.com/city/nagpur"
// let a = 1;

// function check(err, req, html) {
//     if (err) {
//         console.log(err);
//     } else {
//         getdata(html);
//     }

// }
// req(url, check)

// function getdata(html) {
//     let load = cher.load(html);
//     //console.log(load)
//     // let ans = load("#c_articlelist_stories_1 .w_tle a");
//     let ans = load("._3TTdG");
//     console.log((ans).text())
// }

// let a = [10, 20, 30, 40]
// console.log(a.reverse());
// delete(a[0]);
// console.log(a);

// a.shift();
// console.log(a);

// a.unshift(111);

// a.unshift(112);

// a.unshift(113);
// console.log("Array " + a);
// a.sort();
// console.log("reverse " + a);
// let h1 = () => {
//     console.log("Abc")
//     console.log("aaa");
// }
// h1();


// let a = {
//     fname: "Saurabh",
//     lname: "Khandagale",
//     age: 21,
//     a: [10, 30, 40]
// }
// console.log(a.a.indexOf(303))

// async function test() {
//     console.log("a");
//     console.log("b");
//     console.log("c");
// }
// test();
// console.log("aftert");
// console.log("a1");
// console.log("a2");


