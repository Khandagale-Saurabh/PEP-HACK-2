// let a=[
//  { name: "Roorkee", rainfall: [5, 6, 5, 5, 4, 7, 8] },
//  { name: "Pauri", rainfall: [3, 3, 3, 1, 2, 2, 2] },
// ];


// function raindance(a)
// { let s1=0;
// let ans;
// for(let i=0;i<a.length;i++)
// {
   
//    let a2=a[i].rainfall;
// for(let i=0;i<a2.length;i++)
// {
//  s1+=a2[i] 
// }
// console.log(s1/a2.length);
// ans=s1/a2.length;
       
// }

// for(let i=0;i<a.length;i++)
// {
//   console.log(a[i].name);
//   ans=a[i].name
// }

// return  ans
// }
// e=raindance(a)
// console.log(e);

// // //console.log(a[1].rainfall);
// // a1=a[0].rainfall
// // a2=a[1].rainfall

// // // console.log(a1);
// // let s1=0;
// // for(let i=0;i<a1.length;i++)
// // {
// //  s1+=a1[i] 
// // }
// // console.log(s1);

// // let s2=0;
// // for(let i=0;i<a2.length;i++)
// // {
// //  s2+=a2[i] 
// // }
// // console.log(s2);

// // let num=45
// // function decToBin(num)
// // {
// // console.log(""+num.toString(2))
// // }
// // decToBin(num)

//let str="kite flying"
// var str="kite flying";
// function spoon(str)
// {
//   let data=str.split(" ")
//  console.log(data);
//  t1=(data[0].charAt(0))
//  t2=data[1].charAt(0)
  
//   console.log(data);
// }
// spoon(str)


// const a=[10,20]
// a[1]=30
// console.log(a)

let a=function f1()
{
console.log('Hello')
}
console.log()

function f1()
{
console.log('Hello1')
}

f1()