var PaytmConfig = {
  mid: "OyIxgp59875298773399",
  key: "faF9@flLNVkQ9GaY@QXm",
  website: "WEBSTAGING",
};
module.exports.PaytmConfig = PaytmConfig;
